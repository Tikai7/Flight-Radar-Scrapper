# Flight-Radar-Scrapper
This is a scrapper for flightradar in an educational context.
